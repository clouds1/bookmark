import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const Footer = () => {
  const [direction, setDirection] = useState('Right');

  const handlePress = (newDirection) => {
    setDirection(newDirection);
  };

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <TouchableOpacity onPress={() => handlePress('Up')} style={styles.button}>
          <Text style={styles.arrow}>↑</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.row}>
        <TouchableOpacity onPress={() => handlePress('Left')} style={styles.button}>
          <Text style={styles.arrow}>←</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('Down')} style={styles.button}>
          <Text style={styles.arrow}>↓</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handlePress('Right')} style={styles.button}>
          <Text style={styles.arrow}>→</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.directionText}>Direction: {direction}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f8f8f8',
  },
  row: {
    flexDirection: 'row',
    marginVertical: 1,
  },
  button: {
    marginHorizontal: 1,
    padding: 20,
    backgroundColor: '#ddd',
    borderRadius: 5,
  },
  arrow: {
    fontSize: 24,
  },
  directionText: {
    marginTop: 20,
    fontSize: 18,
    color: '#333',
  },
});

export default Footer;