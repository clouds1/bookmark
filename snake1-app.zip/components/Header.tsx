
import { View, Text, StyleSheet } from "react-native"

export function Header({score, highScore}){
    return <>
    <View style={styles.container}>
        <Text style={styles.text}>Score : {score}</Text>
        <Text style={styles.text}>High score: {highScore}</Text>
    </View>
    </>
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        paddingVertical: 10,
        backgroundColor: '#f8f8f8',
    },
    text: {
        fontSize: 18,
        color: '#00000',
        paddingHorizontal: 20,
    },
});
