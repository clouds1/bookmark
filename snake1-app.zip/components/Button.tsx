
import { View } from "react-native"
import { styles } from './Tile.styles'

export function Tile(){
    return (<>
        <View style={styles.square}/>
    </>);
};
