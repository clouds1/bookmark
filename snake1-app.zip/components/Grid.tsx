import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';

const numRows = 16;
const numCols = 16;
const tileSize = Dimensions.get('window').width / numCols; // Calculate tile size to fit the screen width

const Grid: React.FC = () => {
  return (
    <View style={styles.container}>
      {Array.from({ length: numRows }).map((_, rowIndex) => (
        <View key={rowIndex} style={styles.row}>
          {Array.from({ length: numCols }).map((_, colIndex) => (
            <View key={colIndex} style={styles.tile} />
          ))}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  row: {
    flexDirection: 'row',
  },
  tile: {
    width: tileSize,
    height: tileSize,
    backgroundColor: '#ddd', // Change color as needed
    borderWidth: 1,
    borderColor: '#aaa', // Change border color as needed
  },
});

export default Grid;
