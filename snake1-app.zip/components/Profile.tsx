
import { TouchableOpacity, Text } from "react-native"

export function Profile(){
    return <>
        <Text>Hello I am Matt</Text>
        <TouchableOpacity><text>Click me!</text></TouchableOpacity>
    </>
}