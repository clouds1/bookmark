import React, {useState} from "react";
import { Text, View } from "react-native";
import { Profile } from "@/components/Profile";
import { Tile } from "@/components/Tile";
import { Header } from "@/components/Header";
import Footer from "@/components/Footer";
import Grid from "@/components/Grid";

export default function Index() {

  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(10);

  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Header score={score} highScore={highScore} />
      <Grid/>
      <Tile/>
      <Footer/>
    </View>
  );
}
